# 浏览器 —— Android 4.0 专用极简浏览器壳

面向 Android 4.0.3 / 4.0.4（API 14/15）ARMv7 老机型的浏览器工程。

---

## 一、构建环境（老工具链）

| 组件 | 版本 |
|---|---|
| JDK | Temurin OpenJDK **1.8** |
| Gradle | **4.6** |
| Android Gradle Plugin | **3.2.0**（Gradle 4.6 能驱动的较新 AGP；2.3.x 随 jcenter 关闭已不可下载） |
| Build-Tools | **27.0.3** |
| compileSdk | 26（仅编译期使用） |
| minSdkVersion | **14**（Android 4.0） |
| targetSdkVersion | **17**（Android 4.2.2） |
| 语言 | 纯 Java，**无 AndroidX、无 Kotlin、无 support library、无第三方依赖** |

### 构建命令

```bash
export JAVA_HOME=/path/to/jdk8
export ANDROID_HOME=/path/to/android-sdk
cd gecko-browser-shell
gradle assembleDebug
```

产物：`app/build/outputs/apk/debug/app-debug.apk`（debug keystore 签名，已 zipalign）。

`local.properties` 需自行创建（`local.properties.example` 为模板），内容为
`sdk.dir=/your/android/sdk/path`。

---

## 二、工程结构

```
app/src/main/
├── AndroidManifest.xml
├── java/com/geckoshell/browser/
│   ├── MainActivity.java              # 主界面：地址栏、前进后退、下载入口、全屏视频
│   ├── download/
│   │   ├── DownloadManager.java       # 内置下载器（单线程队列、8KB 流式写盘、断点续传）
│   │   ├── DownloadTask.java          # 下载任务数据模型
│   │   ├── DownloadAdapter.java       # 下载列表适配器（ViewHolder 复用）
│   │   └── DownloadActivity.java      # 下载管理界面
│   └── net/
│       └── Tls12SocketFactory.java    # 强制 TLS 1.2 的 SSLSocketFactory
├── java/org/mozilla/gecko/            # Gecko JNI 桥接骨架（当前版本未启用，保留备用）
│   ├── GeckoAppShell.java
│   ├── GeckoThread.java
│   └── mozglue/GeckoLoader.java
├── res/
│   ├── layout/activity_main.xml       # 主界面布局
│   ├── layout/activity_download.xml   # 下载管理布局
│   ├── layout/item_download.xml       # 下载列表单项
│   ├── drawable/bg_url_bar.xml        # 地址栏圆角描边
│   ├── drawable/bg_go_button.xml      # 前往按钮
│   ├── drawable/bg_nav_button.xml     # 圆形导航按钮
│   ├── drawable/bg_progress.xml       # 青色进度条
│   └── values/{colors,strings}.xml
├── assets/
│   └── index.html                     # 内置科技风首页
└── jniLibs/armeabi-v7a/               # 11 个 Gecko 原生库（不在源码包内）
```

---

## 三、功能

- 地址栏 + 前往按钮，自动补 `http://`，中文自动转百度搜索
- 页面在应用内打开，不跳系统浏览器
- 返回键优先网页后退，无历史再退出
- JavaScript / DOM Storage 开启
- 视频：MP4(H.264+AAC) 播放、全屏支持、纯软件渲染
- 内置下载器 + 下载管理界面（队列、进度、取消、重试、断点续传、打开文件）
- 内置科技风首页（`assets/index.html`），首页自动隐藏工具栏
- 强制 TLS 1.2 + 信任所有证书（老机根证书缺失兜底）

---

## 四、关键实现说明

### 1. 强制 TLS 1.2（`net/Tls12SocketFactory.java`）

Android 4.0 的 OpenSSL 底层支持 TLS 1.2，但 `SSLSocket` 默认协商会回落到 TLS 1.0。
本类包装系统 `SSLSocketFactory`，在每个新建 Socket 上显式
`setEnabledProtocols(new String[]{"TLSv1.2"})`，把协议锁死为 TLS 1.2。

- 通过 `SSLContext.getSupportedSSLParameters().getProtocols()` 探测平台能力
- 平台不支持 TLSv1.2 时退化为 `{TLSv1.2, TLSv1.1, TLSv1}`，避免 `IllegalArgumentException`
- 安装到 `HttpsURLConnection.setDefaultSSLSocketFactory()`，内置下载器同样继承

> WebView 内部网络栈由系统控制，壳层无法指定其 TLS 协议版本。
> 本强制策略作用于 `HttpsURLConnection` 链路（下载器与所有 Java 层 HTTPS 请求）。

### 2. Android 4.0 API 兼容守卫

以下方法在低版本会抛 `NoSuchMethodError`，已全部加守卫：

| 方法 | 起始 API | 守卫 |
|---|---|---|
| `WebSettings.setMixedContentMode` | 16 | `SDK_INT >= 16` |
| `WebSettings.setMediaPlaybackRequiresUserGesture` | 17 | `SDK_INT >= 17` |
| `CookieManager.setAcceptThirdPartyCookies` | 21 | `SDK_INT >= 21` |
| `CookieManager.flush` | 21 | `SDK_INT >= 21` |

### 3. 下载器内存设计（老机小堆关键）

- 单线程串行队列，同一时刻只跑一个下载
- 8KB 流式缓冲写盘，绝不把文件读进内存
- 下载线程 `Thread.MIN_PRIORITY`，不抢 UI 线程 CPU
- 进度回调节流：800ms 或进度变化 ≥3% 才通知 UI
- 任务记录上限 30 条，分隔符文本持久化（不引入 JSON 库）
- 落盘优先系统 Download 目录，回退应用私有目录

### 4. 体积治理

原生库用 ARM 交叉 strip 剥离符号：

```bash
arm-none-eabi-strip --strip-unneeded libxul.so
```

`libxul.so` 从 67MB → 36MB，动态链接与 JNI 导出符号完整保留。
APK 最终约 26MB，安装后原生库 + 资源合计约 44MB。

### 5. 架构说明（为什么用 WebView 而非直接加载 Gecko）

`libxul.so` 的 JNI 回调面包含 Fennec 原版数十个 Java 桥接类
（`GeckoAppShell`、`LayerView`、`GeckoEditable`、`EventDispatcher` 等）。
仅实现最小桥接层时，native 初始化会 abort 导致闪退。
因此本工程渲染面使用系统 WebView 保证稳定，Gecko 原生库仍完整打包分发。

---

## 五、已知限制

- WebView 内核版本依赖系统，Android 4.0 为 WebKit，不支持 MSE/DASH 分片流媒体
- TLS 协议版本无法作用于 WebView 内部网络栈
- 信任所有证书仅适用于开发/老机场景，不适合生产分发
