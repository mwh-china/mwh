此目录放置 omni.ja（Gecko 资源包，约 4.9MB）。

来源：Firefox 55.0.2 APK 的 assets/omni.ja
路径：app/src/main/assets/omni.ja

说明：当前版本渲染面使用系统 WebView，omni.ja 仅随包分发、运行时未加载。
若需要精简体积，可从 AndroidManifest 与构建中去掉它。
