package org.mozilla.gecko;

/**
 * Bridge to the Gecko runtime thread.
 *
 * libmozglue.so exports:
 *   Java_org_mozilla_gecko_GeckoThread_registerUiThread
 *
 * libxul.so looks up org/mozilla/gecko/GeckoThread$State via JNI, so the
 * enum must exist with at least the states Gecko references.
 */
public final class GeckoThread {

    /** Tell Gecko which thread is the Android UI thread. */
    public static native void registerUiThread();

    private GeckoThread() {}

    public enum State {
        UNINITIALIZED,
        PRELOAD,
        PREPARED,
        RUNNING,
        EXITING
    }
}
