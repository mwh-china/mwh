package org.mozilla.gecko;

import android.content.Context;
import android.view.Surface;
import org.mozilla.gecko.mozglue.GeckoLoader;

import java.io.File;

/**
 * Minimal embedding shell for Gecko (Firefox 55.0.2).
 *
 * Loads every bundled .so in dependency order, sets the environment
 * variables Gecko expects, then enters the Gecko event loop.
 */
public final class GeckoAppShell {

    private static Context sContext;
    private static Surface sSurface;
    private static String sDefaultUrl = "about:home";
    private static boolean sLibsLoaded = false;

    private GeckoAppShell() {}

    public static void setContext(Context context) {
        sContext = context;
    }

    public static Context getContext() {
        return sContext;
    }

    public static void setSurface(Surface surface) {
        sSurface = surface;
    }

    public static Surface getSurface() {
        return sSurface;
    }

    public static void setDefaultUrl(String url) {
        sDefaultUrl = url;
    }

    public static String getDefaultUrl() {
        return sDefaultUrl;
    }

    /**
     * Load all bundled native libraries in dependency order.
     * libmozglue is loaded in GeckoLoader's static block; we load the rest here.
     * Order matters: libxul needs libmozglue + libnss3 + liblgpllibs.
     */
    public static synchronized void loadNativeLibs() {
        if (sLibsLoaded) return;
        // mozglue already loaded by GeckoLoader static init.
        // NSS stack first: nssckbi and softokn/freebl are pulled by nss3.
        load("nss3");
        load("nssckbi");
        load("softokn3");
        load("freebl3");
        load("lgpllibs");
        // Finally the big one.
        load("xul");
        sLibsLoaded = true;
    }

    private static void load(String name) {
        try {
            System.loadLibrary(name);
        } catch (UnsatisfiedLinkError e) {
            // lgpllibs / omx plugins are optional; xul must succeed.
            if ("xul".equals(name)) {
                throw e;
            }
        }
    }

    /**
     * Set up environment and enter the Gecko event loop.
     * Call on a background thread.
     */
    public static void startGecko(String url) {
        Context ctx = sContext;
        if (ctx == null) {
            throw new IllegalStateException("GeckoAppShell.setContext() not called");
        }

        File nativeLibDir = new File(ctx.getApplicationInfo().nativeLibraryDir);
        File filesDir = ctx.getFilesDir();
        File profileDir = new File(filesDir, "profile");
        if (!profileDir.exists()) {
            profileDir.mkdirs();
        }

        // Load every .so in dependency order.
        loadNativeLibs();

        // Environment variables Gecko expects.
        GeckoLoader.putenv("GRE_HOME", nativeLibDir.getAbsolutePath());
        GeckoLoader.putenv("MOZ_ANDROID_PACKAGE_NAME", ctx.getPackageName());
        GeckoLoader.putenv("MOZ_ANDROID_USER_SERIAL_NUMBER", "0");
        GeckoLoader.putenv("HOME", filesDir.getAbsolutePath());
        GeckoLoader.putenv("TMPDIR", ctx.getCacheDir().getAbsolutePath());

        try {
            GeckoThread.registerUiThread();
        } catch (Throwable e) {
            // non-fatal
        }

        if (url == null || url.length() == 0) {
            url = sDefaultUrl;
        }

        String[] args = new String[] {
            "gecko",
            "-no-remote",
            "-profile", profileDir.getAbsolutePath(),
            url
        };

        GeckoLoader.nativeRun(args);
    }
}
