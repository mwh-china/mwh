package org.mozilla.gecko.mozglue;

/**
 * Java bridge to libmozglue.so.
 *
 * We deliberately do NOT call loadGeckoLibsNative / loadNSSLibsNative /
 * loadSQLiteLibsNative from Java: those expect a real APK file descriptor
 * and would SIGSEGV on a generic shell.  Instead the activity loads every
 * .so in dependency order with System.loadLibrary(), then calls nativeRun.
 */
public final class GeckoLoader {

    static {
        System.loadLibrary("mozglue");
    }

    private GeckoLoader() {}

    /** Enter the Gecko event loop on the calling thread. Blocks. */
    public static native void nativeRun(String[] args);

    public static native boolean neonCompatible();

    public static native void putenv(String key, String value);

    public static native void suppressCrashDialog();
}
