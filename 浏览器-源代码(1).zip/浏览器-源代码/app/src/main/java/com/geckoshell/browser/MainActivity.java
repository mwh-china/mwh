package com.geckoshell.browser;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.SslErrorHandler;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.geckoshell.browser.download.DownloadManager;
import com.geckoshell.browser.download.DownloadTask;
import com.geckoshell.browser.net.Tls12SocketFactory;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;

/**
 * 浏览器 —— 极简浏览器壳。
 *
 * 渲染面：系统 WebView。
 *  - 现代 Chrome 移动版 UA，绕过反爬
 *  - 信任所有证书，SSL 错误直接 proceed
 *  - 视频自动播放 + 全屏支持（H.264/AAC MP4）
 *  - 内置科技风首页（file:///android_asset/index.html）
 */
public class MainActivity extends Activity {

    private static final String MODERN_UA =
            "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/110.0.0.0 Mobile Safari/537.36";

    private EditText mUrlBar;
    private WebView mWebView;
    private ProgressBar mProgressBar;
    private TextView mBackBtn;
    private TextView mForwardBtn;
    private View mCustomView;
    private WebChromeClient.CustomViewCallback mCustomCallback;
    private View mToolbar;
    private static final String HOME_URL = "file:///android_asset/index.html";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setupTls();

        mUrlBar = (EditText) findViewById(R.id.url_bar);
        mWebView = (WebView) findViewById(R.id.web_view);
        mProgressBar = (ProgressBar) findViewById(R.id.progress_bar);
        mBackBtn = (TextView) findViewById(R.id.back_btn);
        mForwardBtn = (TextView) findViewById(R.id.forward_btn);
        mToolbar = findViewById(R.id.toolbar);
        Button goBtn = (Button) findViewById(R.id.go_btn);
        View dlBtn = findViewById(R.id.dl_btn);
        dlBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,
                        com.geckoshell.browser.download.DownloadActivity.class));
            }
        });

        // 纯软件解码：关闭硬件加速层，视频走软件渲染
        mWebView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);

        WebSettings s = mWebView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setUserAgentString(MODERN_UA);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setAllowFileAccess(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        // 磁盘缓存 + 应用缓存，加速二次打开
        s.setAppCacheEnabled(true);
        s.setAppCachePath(getCacheDir().getAbsolutePath());
        s.setAppCacheMaxSize(10 * 1024 * 1024);
        s.setDatabaseEnabled(true);
        s.setDatabasePath(getDatabasePath("webview.db").getAbsolutePath());
        // 渲染线程优先，滚动/绘制更跟手
        s.setRenderPriority(WebSettings.RenderPriority.HIGH);
        // 图片自动加载，按视口尺寸缩放（配合 overview mode）
        s.setLoadsImagesAutomatically(true);
        // 视频：允许自动播放（不需用户手势），让 B 站视频自动起播
        // 视频自动播放：API 17 才有此方法，Android 4.0 上跳过（否则 NoSuchMethodError 闪退）
        if (android.os.Build.VERSION.SDK_INT >= 17) {
            s.setMediaPlaybackRequiresUserGesture(false);
        }
        if (android.os.Build.VERSION.SDK_INT >= 16) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
        CookieManager.getInstance().setAcceptCookie(true);
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(mWebView, true);
        }

        // 文件下载：交给内置下载器（带 cookie / UA，支持队列+管理+续传）
        mWebView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent,
                                        String contentDisposition, String mimetype,
                                        long contentLength) {
                try {
                    DownloadTask task = new DownloadTask();
                    task.id = String.valueOf(System.currentTimeMillis());
                    task.url = url;
                    task.mimeType = mimetype;
                    task.fileName = URLUtil.guessFileName(url, contentDisposition, mimetype);
                    task.cookies = CookieManager.getInstance().getCookie(url);
                    task.userAgent = userAgent;
                    task.totalBytes = contentLength;
                    DownloadManager.get(MainActivity.this).enqueue(task);
                    Toast.makeText(MainActivity.this, "开始下载: " + task.fileName,
                            Toast.LENGTH_SHORT).show();
                } catch (Throwable e) {
                    Toast.makeText(MainActivity.this, "下载失败: " + e,
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                mUrlBar.setText(url);
                updateNavButtons();
                // flush() 是 API 21 才有的方法，低版本跳过
                if (android.os.Build.VERSION.SDK_INT >= 21) {
                    CookieManager.getInstance().flush();
                }
                // 首页隐藏工具栏，网页显示工具栏
                if (url != null && url.equals(HOME_URL)) {
                    mToolbar.setVisibility(View.GONE);
                } else {
                    mToolbar.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler,
                                           android.net.http.SslError error) {
                handler.proceed();
            }

            @Override
            public void onReceivedError(WebView view, int errorCode,
                                        String description, String failingUrl) {
                Toast.makeText(MainActivity.this,
                        "加载失败: " + description, Toast.LENGTH_SHORT).show();
            }
        });

        mWebView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                mProgressBar.setProgress(newProgress);
                mProgressBar.setVisibility(newProgress < 100 ? View.VISIBLE : View.GONE);
            }

            // 全屏视频支持（点 B 站全屏按钮时）
            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (mCustomView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                mCustomView = view;
                mCustomCallback = callback;
                mWebView.setVisibility(View.GONE);
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                ((FrameLayout) getWindow().getDecorView()).addView(view,
                        new FrameLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT));
            }

            @Override
            public void onHideCustomView() {
                if (mCustomView == null) return;
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                ((FrameLayout) getWindow().getDecorView()).removeView(mCustomView);
                mCustomView = null;
                mWebView.setVisibility(View.VISIBLE);
                if (mCustomCallback != null) mCustomCallback.onCustomViewHidden();
                mCustomCallback = null;
            }
        });

        goBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadCurrentUrl();
            }
        });

        mUrlBar.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_GO
                        || actionId == EditorInfo.IME_ACTION_DONE) {
                    loadCurrentUrl();
                    return true;
                }
                return false;
            }
        });

        mBackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mWebView.canGoBack()) mWebView.goBack();
            }
        });
        mForwardBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mWebView.canGoForward()) mWebView.goForward();
            }
        });

        // 内置科技风首页
        mWebView.loadUrl("file:///android_asset/index.html");
    }

    private void loadCurrentUrl() {
        String url = mUrlBar.getText().toString().trim();
        if (url.length() == 0) {
            Toast.makeText(this, "请输入网址", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!url.startsWith("http://") && !url.startsWith("https://")
                && !url.startsWith("about:") && !url.startsWith("file://")) {
            url = "http://" + url;
        }
        mWebView.loadUrl(url);
    }

    private void updateNavButtons() {
        mBackBtn.setEnabled(mWebView.canGoBack());
        mForwardBtn.setEnabled(mWebView.canGoForward());
        mBackBtn.setAlpha(mWebView.canGoBack() ? 1f : 0.4f);
        mForwardBtn.setAlpha(mWebView.canGoForward() ? 1f : 0.4f);
    }

    /**
     * 安装 TLS 1.2 强制工厂 + 信任所有证书 + 全放行主机名校验。
     * 所有 HttpsURLConnection（含内置下载器）都会走这条链路。
     */
    private void setupTls() {
        // 强制 TLS 1.2（Android 4.0 底层 OpenSSL 支持，但默认会回落 TLS 1.0）
        int protoCount = Tls12SocketFactory.install();
        // 主机名校验放行（老机证书链不全时避免握手失败）
        try {
            HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {
                public boolean verify(String hostname, SSLSession session) { return true; }
            });
        } catch (Throwable ignored) {}
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        // 后台/低内存时释放 WebView 缓存，防止越用越卡
        if (mWebView != null) {
            mWebView.clearCache(true);
            mWebView.clearHistory();
        }
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (level >= TRIM_MEMORY_BACKGROUND && mWebView != null) {
            mWebView.clearCache(true);
        }
    }

    @Override
    public void onBackPressed() {
        // 全屏视频先退出全屏
        if (mCustomView != null) {
            mWebView.getWebChromeClient().onHideCustomView();
            return;
        }
        if (mWebView.canGoBack()) {
            mWebView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
