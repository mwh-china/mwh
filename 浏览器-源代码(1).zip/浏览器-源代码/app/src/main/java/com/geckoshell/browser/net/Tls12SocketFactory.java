package com.geckoshell.browser.net;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;

import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/**
 * 强制 TLS 1.2 的 SocketFactory（针对 Android 4.0 优化）。
 *
 * 背景：Android 4.0（API 14/15）的 SSLSocket 底层 OpenSSL 支持 TLS 1.2，
 * 但默认协商仍会回落到 TLS 1.0，导致被现代站点/Cloudflare 拒绝。
 * 本类在每个新建 Socket 上显式 setEnabledProtocols，把协议锁死为 TLSv1.2。
 *
 * 同时内置 trust-all TrustManager，解决老机根证书缺失导致的握手失败。
 *
 * 兼容性处理：若个别 ROM 的 SSLSocket 不支持 TLSv1.2，
 * 会退化为 TLSv1.1/TLSv1 而不是直接崩溃。
 */
public final class Tls12SocketFactory extends SSLSocketFactory {

    /** 首选协议：只允许 TLS 1.2 */
    private static final String[] PROTOCOLS_STRICT = {"TLSv1.2"};
    /** 退化协议：极端老 ROM 不支持 1.2 时使用（仍优先 1.2） */
    private static final String[] PROTOCOLS_FALLBACK = {"TLSv1.2", "TLSv1.1", "TLSv1"};

    private final SSLSocketFactory delegate;
    private final String[] protocols;

    private Tls12SocketFactory(SSLSocketFactory delegate, String[] protocols) {
        this.delegate = delegate;
        this.protocols = protocols;
    }

    /* ---------------- 静态安装入口 ---------------- */

    /**
     * 创建并安装全局 TLS 1.2 工厂。
     * 返回实际生效的协议列表长度，便于调用方记录日志。
     */
    public static int install() {
        try {
            SSLContext sc = buildContext();
            Tls12SocketFactory factory = new Tls12SocketFactory(
                    sc.getSocketFactory(), pickProtocols(sc));
            javax.net.ssl.HttpsURLConnection.setDefaultSSLSocketFactory(factory);
            return factory.protocols.length;
        } catch (Throwable e) {
            // 安装失败不影响主流程；下载器会走系统默认工厂
            return 0;
        }
    }

    /** 构建带 trust-all 的 SSLContext，优先 TLSv1.2 算法。 */
    private static SSLContext buildContext() throws NoSuchAlgorithmException, KeyManagementException {
        SSLContext sc = null;
        try {
            sc = SSLContext.getInstance("TLSv1.2");
        } catch (NoSuchAlgorithmException ignored) {
            // 老 ROM 没有 TLSv1.2 算法名，退回通用 TLS
        }
        if (sc == null) {
            sc = SSLContext.getInstance("TLS");
        }
        TrustManager[] tms = new TrustManager[]{new X509TrustManager() {
            public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
            public void checkClientTrusted(X509Certificate[] chain, String authType) { }
            public void checkServerTrusted(X509Certificate[] chain, String authType) { }
        }};
        sc.init((KeyManager[]) null, tms, new SecureRandom());
        return sc;
    }

    /** 判断该平台是否真的支持 TLSv1.2（读取 supported protocols）。 */
    private static String[] pickProtocols(SSLContext sc) {
        try {
            SSLContext probe = SSLContext.getInstance("TLS");
            String[] supported = probe.getSupportedSSLParameters().getProtocols();
            if (supported != null) {
                for (int i = 0; i < supported.length; i++) {
                    if ("TLSv1.2".equals(supported[i])) {
                        return PROTOCOLS_STRICT;
                    }
                }
            }
        } catch (Throwable ignored) {}
        return PROTOCOLS_FALLBACK;
    }

    /* ---------------- 每个 Socket 强制协议 ---------------- */

    private Socket harden(Socket socket) {
        if (socket instanceof SSLSocket) {
            try {
                ((SSLSocket) socket).setEnabledProtocols(protocols);
            } catch (Throwable ignored) {
                // 协议不被支持时保持默认，避免抛 IllegalArgumentException
            }
        }
        return socket;
    }

    @Override
    public String[] getDefaultCipherSuites() {
        return delegate.getDefaultCipherSuites();
    }

    @Override
    public String[] getSupportedCipherSuites() {
        return delegate.getSupportedCipherSuites();
    }

    @Override
    public Socket createSocket(Socket s, String host, int port, boolean autoClose)
            throws IOException {
        return harden(delegate.createSocket(s, host, port, autoClose));
    }

    @Override
    public Socket createSocket(String host, int port) throws IOException {
        return harden(delegate.createSocket(host, port));
    }

    @Override
    public Socket createSocket(String host, int port, InetAddress localHost,
                               int localPort) throws IOException {
        return harden(delegate.createSocket(host, port, localHost, localPort));
    }

    @Override
    public Socket createSocket(InetAddress host, int port) throws IOException {
        return harden(delegate.createSocket(host, port));
    }

    @Override
    public Socket createSocket(InetAddress address, int port,
                               InetAddress localAddress, int localPort) throws IOException {
        return harden(delegate.createSocket(address, port, localAddress, localPort));
    }
}
