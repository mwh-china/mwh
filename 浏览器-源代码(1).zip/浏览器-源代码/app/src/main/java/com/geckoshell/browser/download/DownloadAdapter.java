package com.geckoshell.browser.download;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.geckoshell.browser.R;

import java.util.ArrayList;
import java.util.List;

/**
 * 下载列表适配器。
 * Android 4.0 优化：标准 ViewHolder 复用，每次绑定不新建对象；
 * 列表数据每次全量替换为浅拷贝（30 条上限，开销可忽略）。
 */
public class DownloadAdapter extends BaseAdapter {

    private final Context ctx;
    private final LayoutInflater inflater;
    private final List<DownloadTask> data = new ArrayList<DownloadTask>();
    private final OnActionListener listener;

    public interface OnActionListener {
        void onAction(DownloadTask task);
    }

    static class Holder {
        TextView name;
        TextView status;
        TextView size;
        TextView action;
        ProgressBar progress;
    }

    public DownloadAdapter(Context ctx, OnActionListener l) {
        this.ctx = ctx;
        this.inflater = LayoutInflater.from(ctx);
        this.listener = l;
    }

    public void setData(List<DownloadTask> list) {
        data.clear();
        if (list != null) data.addAll(list);
        notifyDataSetChanged();
    }

    @Override
    public int getCount() { return data.size(); }

    @Override
    public DownloadTask getItem(int position) { return data.get(position); }

    @Override
    public long getItemId(int position) { return position; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Holder h;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_download, parent, false);
            h = new Holder();
            h.name = (TextView) convertView.findViewById(R.id.item_name);
            h.status = (TextView) convertView.findViewById(R.id.item_status);
            h.size = (TextView) convertView.findViewById(R.id.item_size);
            h.action = (TextView) convertView.findViewById(R.id.item_action);
            h.progress = (ProgressBar) convertView.findViewById(R.id.item_progress);
            convertView.setTag(h);
        } else {
            h = (Holder) convertView.getTag();
        }

        final DownloadTask t = data.get(position);
        h.name.setText(t.fileName != null ? t.fileName : "未命名");

        h.status.setText(t.error != null && t.status == DownloadTask.STATUS_FAILED
                ? "失败：" + t.error : t.statusText());

        switch (t.status) {
            case DownloadTask.STATUS_DONE:
                h.action.setText("打开");
                h.action.setVisibility(View.VISIBLE);
                h.progress.setProgress(100);
                break;
            case DownloadTask.STATUS_RUNNING:
                h.action.setText("取消");
                h.action.setVisibility(View.VISIBLE);
                h.progress.setProgress(t.progress);
                break;
            case DownloadTask.STATUS_PENDING:
                h.action.setText("取消");
                h.action.setVisibility(View.VISIBLE);
                h.progress.setProgress(0);
                break;
            case DownloadTask.STATUS_FAILED:
            case DownloadTask.STATUS_CANCELLED:
                h.action.setText("重试");
                h.action.setVisibility(View.VISIBLE);
                h.progress.setProgress(0);
                break;
            default:
                h.action.setVisibility(View.GONE);
                break;
        }

        if (t.totalBytes > 0) {
            h.size.setText(DownloadManager.formatSize(t.downloadedBytes)
                    + " / " + DownloadManager.formatSize(t.totalBytes));
        } else if (t.downloadedBytes > 0) {
            h.size.setText(DownloadManager.formatSize(t.downloadedBytes));
        } else {
            h.size.setText("");
        }

        h.action.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) listener.onAction(t);
            }
        });

        return convertView;
    }
}
