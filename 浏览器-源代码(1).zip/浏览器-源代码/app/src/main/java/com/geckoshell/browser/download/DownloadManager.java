package com.geckoshell.browser.download;

import android.content.Context;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 内置下载器（针对 Android 4.0 小内存优化）。
 *
 * 设计要点：
 *  - 单线程串行队列：同一时刻只跑一个下载，峰值内存最低
 *  - 8KB 流式写盘，绝不把文件内容读进内存（老机堆只有 16~32MB）
 *  - 进度回调节流：每 800ms 或进度变化 ≥3% 才通知 UI，避免频繁重绘卡顿
 *  - 任务列表用分隔符文本持久化，不用 JSON 库，省内存省 dex
 *  - 只保留最近 30 条记录，防止列表无限增长
 */
public final class DownloadManager {

    private static final int BUFFER_SIZE = 8 * 1024;
    private static final long PROGRESS_INTERVAL_MS = 800;
    private static final int PROGRESS_MIN_DELTA = 3;
    private static final int MAX_TASKS = 30;

    private static DownloadManager sInstance;

    private final Context appContext;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final List<DownloadTask> tasks = new ArrayList<DownloadTask>();
    private final List<DownloadTask> queue = new ArrayList<DownloadTask>();
    private final List<Listener> listeners = new ArrayList<Listener>();

    private Thread worker;
    private volatile boolean working = false;
    private volatile DownloadTask current;

    /** 下载状态变化回调（在 UI 线程触发）。 */
    public interface Listener {
        void onDownloadsChanged();
    }

    private DownloadManager(Context ctx) {
        this.appContext = ctx.getApplicationContext();
        loadTasks();
    }

    public static synchronized DownloadManager get(Context ctx) {
        if (sInstance == null) {
            sInstance = new DownloadManager(ctx);
        }
        return sInstance;
    }

    /* ---------------- 对外接口 ---------------- */

    public synchronized List<DownloadTask> getTasks() {
        return new ArrayList<DownloadTask>(tasks);
    }

    public void addListener(Listener l) {
        if (l != null && !listeners.contains(l)) listeners.add(l);
    }

    public void removeListener(Listener l) {
        listeners.remove(l);
    }

    /** 新任务入队并立即尝试启动。 */
    public synchronized void enqueue(DownloadTask task) {
        if (task == null || TextUtils.isEmpty(task.url)) return;
        task.status = DownloadTask.STATUS_PENDING;
        task.progress = 0;
        task.downloadedBytes = 0;
        tasks.add(0, task);
        trimTasks();
        queue.add(task);
        saveTasks();
        notifyChanged();
        startWorkerIfNeeded();
    }

    public synchronized void cancel(DownloadTask task) {
        if (task == null) return;
        if (task == current) {
            task.status = DownloadTask.STATUS_CANCELLED;
        } else {
            queue.remove(task);
            task.status = DownloadTask.STATUS_CANCELLED;
        }
        saveTasks();
        notifyChanged();
    }

    public synchronized void remove(DownloadTask task) {
        if (task == null) return;
        if (task == current) return; // 正在下载的不允许直接删
        queue.remove(task);
        tasks.remove(task);
        saveTasks();
        notifyChanged();
    }

    public synchronized void retry(DownloadTask task) {
        if (task == null) return;
        if (task.isRunning()) return;
        task.status = DownloadTask.STATUS_PENDING;
        task.progress = 0;
        task.downloadedBytes = 0;
        task.error = null;
        if (!tasks.contains(task)) tasks.add(0, task);
        if (!queue.contains(task)) queue.add(task);
        saveTasks();
        notifyChanged();
        startWorkerIfNeeded();
    }

    /** 清空已完成的任务记录。 */
    public synchronized void clearFinished() {
        for (int i = tasks.size() - 1; i >= 0; i--) {
            DownloadTask t = tasks.get(i);
            if (t.status == DownloadTask.STATUS_DONE
                    || t.status == DownloadTask.STATUS_FAILED
                    || t.status == DownloadTask.STATUS_CANCELLED) {
                tasks.remove(i);
            }
        }
        saveTasks();
        notifyChanged();
    }

    /* ---------------- 工作线程 ---------------- */

    private synchronized void startWorkerIfNeeded() {
        if (working || queue.isEmpty()) return;
        working = true;
        worker = new Thread(new Runnable() {
            @Override
            public void run() {
                loop();
            }
        }, "Downloader");
        // 老机给下载线程低优先级，避免抢占 UI 线程 CPU
        worker.setPriority(Thread.MIN_PRIORITY);
        worker.start();
    }

    private void loop() {
        while (true) {
            DownloadTask task;
            synchronized (this) {
                if (queue.isEmpty()) {
                    working = false;
                    current = null;
                    return;
                }
                task = queue.remove(0);
                current = task;
                task.status = DownloadTask.STATUS_RUNNING;
            }
            notifyChanged();
            download(task);
            synchronized (this) {
                current = null;
            }
            notifyChanged();
        }
    }

    private void download(DownloadTask task) {
        HttpURLConnection conn = null;
        InputStream in = null;
        BufferedOutputStream out = null;
        try {
            URL url = new URL(task.url);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(20000);
            conn.setReadTimeout(30000);
            conn.setRequestProperty("User-Agent", task.userAgent != null
                    ? task.userAgent : "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36");
            if (task.cookies != null && task.cookies.length() > 0) {
                conn.setRequestProperty("Cookie", task.cookies);
            }
            // 断点续传：已有部分文件时带 Range
            File target = resolveTargetFile(task);
            long existing = target.exists() ? target.length() : 0;
            if (existing > 0 && task.totalBytes > 0 && existing < task.totalBytes) {
                conn.setRequestProperty("Range", "bytes=" + existing + "-");
            }
            conn.setInstanceFollowRedirects(true);
            conn.connect();

            int code = conn.getResponseCode();
            if (code == 206) {
                // 续传成功
            } else if (code >= 400) {
                throw new IOExceptionCode(code);
            }

            long total = conn.getContentLength();
            if (total > 0) {
                task.totalBytes = existing > 0 ? existing + total : total;
            }

            in = new BufferedInputStream(conn.getInputStream(), BUFFER_SIZE);
            out = new BufferedOutputStream(new FileOutputStream(target, existing > 0), BUFFER_SIZE);
            task.filePath = target.getAbsolutePath();

            byte[] buf = new byte[BUFFER_SIZE];
            long lastNotify = 0;
            int lastProgress = -1;
            int read;
            long done = existing;
            while ((read = in.read(buf)) != -1) {
                if (task.status == DownloadTask.STATUS_CANCELLED) break;
                out.write(buf, 0, read);
                done += read;
                task.downloadedBytes = done;

                int p = task.totalBytes > 0
                        ? (int) (done * 100 / task.totalBytes) : 0;
                long now = System.currentTimeMillis();
                if (p - lastProgress >= PROGRESS_MIN_DELTA
                        || now - lastNotify >= PROGRESS_INTERVAL_MS) {
                    task.progress = p;
                    lastProgress = p;
                    lastNotify = now;
                    notifyChanged();
                }
            }
            out.flush();

            if (task.status == DownloadTask.STATUS_CANCELLED) {
                // 取消：删掉半截文件
                try { target.delete(); } catch (Throwable ignored) {}
            } else {
                task.progress = 100;
                task.status = DownloadTask.STATUS_DONE;
            }
        } catch (Throwable e) {
            if (task.status != DownloadTask.STATUS_CANCELLED) {
                task.status = DownloadTask.STATUS_FAILED;
                task.error = e.toString();
            }
        } finally {
            closeQuietly(in);
            closeQuietly(out);
            if (conn != null) conn.disconnect();
            saveTasks();
        }
    }

    private static void closeQuietly(java.io.Closeable c) {
        if (c != null) { try { c.close(); } catch (Throwable ignored) {} }
    }

    /** 中间异常：HTTP 状态码错误。 */
    private static class IOExceptionCode extends Exception {
        IOExceptionCode(int code) { super("HTTP " + code); }
    }

    /** 选择落盘路径：优先外部 Download 目录，失败回退应用私有目录。 */
    private File resolveTargetFile(DownloadTask task) {
        String name = task.fileName;
        if (TextUtils.isEmpty(name)) name = "download_" + System.currentTimeMillis();
        name = sanitize(name);

        File dir = null;
        try {
            File ext = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (ext != null) {
                if (!ext.exists()) ext.mkdirs();
                if (ext.canWrite()) dir = ext;
            }
        } catch (Throwable ignored) {}
        if (dir == null) {
            File f = appContext.getExternalFilesDir(null);
            if (f != null) {
                File d = new File(f, "downloads");
                if (!d.exists()) d.mkdirs();
                dir = d;
            }
        }
        if (dir == null) {
            File d = new File(appContext.getFilesDir(), "downloads");
            if (!d.exists()) d.mkdirs();
            dir = d;
        }
        File target = new File(dir, name);
        // 同名去重
        int i = 1;
        while (target.exists() && target.length() > 0
                && task.downloadedBytes == 0 && i < 100) {
            String base = name, ext2 = "";
            int dot = name.lastIndexOf('.');
            if (dot > 0) { base = name.substring(0, dot); ext2 = name.substring(dot); }
            target = new File(dir, base + "(" + i + ")" + ext2);
            i++;
        }
        return target;
    }

    private static String sanitize(String name) {
        StringBuilder sb = new StringBuilder(name.length());
        for (int i = 0; i < name.length(); i++) {
            char c = name.charAt(i);
            if (c == '/' || c == '\\' || c == ':' || c == '*' || c == '?'
                    || c == '"' || c == '<' || c == '>' || c == '|') {
                sb.append('_');
            } else {
                sb.append(c);
            }
        }
        String s = sb.toString().trim();
        return s.length() == 0 ? "download" : s;
    }

    /* ---------------- 通知 UI ---------------- */

    private void notifyChanged() {
        if (listeners.isEmpty()) return;
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                List<Listener> copy = new ArrayList<Listener>(listeners);
                for (int i = 0; i < copy.size(); i++) {
                    try { copy.get(i).onDownloadsChanged(); } catch (Throwable ignored) {}
                }
            }
        });
    }

    private void trimTasks() {
        while (tasks.size() > MAX_TASKS) {
            tasks.remove(tasks.size() - 1);
        }
    }

    /* ---------------- 持久化（分隔符文本，省内存） ---------------- */

    private void saveTasks() {
        try {
            StringBuilder sb = new StringBuilder();
            synchronized (this) {
                for (int i = 0; i < tasks.size(); i++) {
                    DownloadTask t = tasks.get(i);
                    sb.append(esc(t.url)).append('\t')
                      .append(esc(t.fileName)).append('\t')
                      .append(esc(t.filePath)).append('\t')
                      .append(t.totalBytes).append('\t')
                      .append(t.downloadedBytes).append('\t')
                      .append(t.status).append('\t')
                      .append(esc(t.mimeType)).append('\t')
                      .append(esc(t.error)).append('\n');
                }
            }
            appContext.getSharedPreferences("downloads", Context.MODE_PRIVATE)
                    .edit().putString("list", sb.toString()).commit();
        } catch (Throwable ignored) {}
    }

    private void loadTasks() {
        try {
            String data = appContext.getSharedPreferences("downloads", Context.MODE_PRIVATE)
                    .getString("list", "");
            if (TextUtils.isEmpty(data)) return;
            String[] lines = data.split("\n");
            synchronized (this) {
                for (int i = 0; i < lines.length; i++) {
                    String line = lines[i];
                    if (line.length() == 0) continue;
                    String[] p = line.split("\t");
                    if (p.length < 7) continue;
                    DownloadTask t = new DownloadTask();
                    t.url = unesc(p[0]);
                    t.fileName = unesc(p[1]);
                    t.filePath = unesc(p[2]);
                    t.totalBytes = parseLong(p[3]);
                    t.downloadedBytes = parseLong(p[4]);
                    int st = (int) parseLong(p[5]);
                    // 重启后不保留"排队中/下载中"状态，改为失败待重试
                    if (st == DownloadTask.STATUS_PENDING || st == DownloadTask.STATUS_RUNNING) {
                        st = DownloadTask.STATUS_FAILED;
                    }
                    t.status = st;
                    t.mimeType = unesc(p[6]);
                    t.error = p.length > 7 ? unesc(p[7]) : null;
                    if (t.totalBytes > 0) {
                        t.progress = (int) (t.downloadedBytes * 100 / t.totalBytes);
                    }
                    tasks.add(t);
                }
            }
        } catch (Throwable ignored) {}
    }

    private static long parseLong(String s) {
        try { return Long.parseLong(s); } catch (Throwable e) { return 0; }
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\t", " ").replace("\n", " ");
    }

    private static String unesc(String s) {
        if (s == null) return "";
        return s.replace("\\\\", "\\");
    }

    /* ---------------- 工具 ---------------- */

    public static String formatSize(long bytes) {
        if (bytes <= 0) return "--";
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return (bytes / 1024) + " KB";
        if (bytes < 1024L * 1024 * 1024) {
            return String.format("%.1f MB", bytes / 1024.0 / 1024.0);
        }
        return String.format("%.2f GB", bytes / 1024.0 / 1024.0 / 1024.0);
    }
}
