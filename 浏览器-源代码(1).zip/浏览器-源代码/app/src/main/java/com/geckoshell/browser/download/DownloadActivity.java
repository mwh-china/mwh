package com.geckoshell.browser.download;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.geckoshell.browser.R;

import java.io.File;
import java.util.List;

/**
 * 下载管理界面。
 * Android 4.0 优化：ListView 复用、进度刷新节流（1 秒一次）、无动画。
 */
public class DownloadActivity extends Activity implements DownloadManager.Listener {

    private DownloadManager dm;
    private DownloadAdapter adapter;
    private ListView list;
    private View empty;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private boolean pendingRefresh = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_download);

        dm = DownloadManager.get(this);

        list = (ListView) findViewById(R.id.dl_list);
        empty = findViewById(R.id.dl_empty);

        adapter = new DownloadAdapter(this, new DownloadAdapter.OnActionListener() {
            @Override
            public void onAction(DownloadTask task) {
                handleAction(task);
            }
        });
        list.setAdapter(adapter);

        // 长按删除记录
        list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                DownloadTask t = adapter.getItem(position);
                if (t != null && !t.isRunning()) {
                    dm.remove(t);
                    Toast.makeText(DownloadActivity.this, "已删除记录", Toast.LENGTH_SHORT).show();
                    return true;
                }
                return false;
            }
        });

        findViewById(R.id.dl_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { finish(); }
        });

        findViewById(R.id.dl_clear).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dm.clearFinished();
                Toast.makeText(DownloadActivity.this, "已清除完成记录", Toast.LENGTH_SHORT).show();
            }
        });

        dm.addListener(this);
        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        dm.addListener(this);
        refresh();
    }

    @Override
    protected void onPause() {
        super.onPause();
        dm.removeListener(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        dm.removeListener(this);
        ui.removeCallbacksAndMessages(null);
    }

    /** 节流刷新：1 秒最多刷一次，避免老机滚动时反复重绘。 */
    @Override
    public void onDownloadsChanged() {
        if (pendingRefresh) return;
        pendingRefresh = true;
        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                pendingRefresh = false;
                refresh();
            }
        }, 1000);
    }

    private void refresh() {
        List<DownloadTask> tasks = dm.getTasks();
        adapter.setData(tasks);
        if (tasks.isEmpty()) {
            empty.setVisibility(View.VISIBLE);
            list.setVisibility(View.GONE);
        } else {
            empty.setVisibility(View.GONE);
            list.setVisibility(View.VISIBLE);
        }
    }

    private void handleAction(DownloadTask t) {
        if (t == null) return;
        switch (t.status) {
            case DownloadTask.STATUS_DONE:
                openFile(t);
                break;
            case DownloadTask.STATUS_RUNNING:
            case DownloadTask.STATUS_PENDING:
                dm.cancel(t);
                Toast.makeText(this, "已取消", Toast.LENGTH_SHORT).show();
                break;
            default:
                dm.retry(t);
                Toast.makeText(this, "重新下载", Toast.LENGTH_SHORT).show();
                break;
        }
    }

    private void openFile(DownloadTask t) {
        if (t.filePath == null) {
            Toast.makeText(this, "文件路径缺失", Toast.LENGTH_SHORT).show();
            return;
        }
        File f = new File(t.filePath);
        if (!f.exists()) {
            Toast.makeText(this, "文件不存在，可能已被删除", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(Uri.fromFile(f),
                    t.mimeType != null && t.mimeType.length() > 0
                            ? t.mimeType : "*/*");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Throwable e) {
            Toast.makeText(this, "没有可打开此文件的应用", Toast.LENGTH_SHORT).show();
        }
    }
}
