package com.geckoshell.browser.download;

/**
 * 单个下载任务的数据模型（纯 Java，无 UI 依赖）。
 */
public class DownloadTask {

    public static final int STATUS_PENDING   = 0;
    public static final int STATUS_RUNNING   = 1;
    public static final int STATUS_DONE      = 2;
    public static final int STATUS_FAILED    = 3;
    public static final int STATUS_CANCELLED = 4;

    public String id;
    public String url;
    public String fileName;
    public String mimeType;
    public String cookies;
    public String userAgent;
    public String filePath;
    public long totalBytes;
    public long downloadedBytes;
    public int progress;
    public int status = STATUS_PENDING;
    public String error;

    public DownloadTask() {}

    public String statusText() {
        switch (status) {
            case STATUS_PENDING:   return "排队中";
            case STATUS_RUNNING:   return "下载中 " + progress + "%";
            case STATUS_DONE:      return "已完成";
            case STATUS_FAILED:    return "下载失败";
            case STATUS_CANCELLED: return "已取消";
            default: return "";
        }
    }

    public boolean isDone()      { return status == STATUS_DONE; }
    public boolean isRunning()   { return status == STATUS_RUNNING || status == STATUS_PENDING; }
}
