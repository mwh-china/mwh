此目录需放入以下 11 个 ARMv7 原生库（Firefox 55.0.2，armeabi-v7a）：

  libxul.so            （建议 strip：arm-none-eabi-strip --strip-unneeded libxul.so）
  libmozglue.so
  libnss3.so
  libnssckbi.so
  libsoftokn3.so
  libfreebl3.so
  liblgpllibs.so
  libomxplugin.so
  libomxpluginkk.so
  libplugin-container.so
  libplugin-container-pie.so

注意：若原始文件是 XZ 压缩格式（file 显示 "XZ compressed data"），
需先解压：xz -dc libxul.so.xz > libxul.so

同时把 omni.ja 放入 app/src/main/assets/omni.ja
